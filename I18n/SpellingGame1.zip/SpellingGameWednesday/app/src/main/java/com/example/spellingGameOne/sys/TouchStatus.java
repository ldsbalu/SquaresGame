package com.example.spellingGameOne.sys;

public enum TouchStatus{
    CONTINUE, LEVEL_COMPLETE, TRY_AGAIN
}
