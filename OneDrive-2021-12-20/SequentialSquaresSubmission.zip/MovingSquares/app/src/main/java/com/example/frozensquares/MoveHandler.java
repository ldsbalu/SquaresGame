package com.example.frozensquares;

import android.os.Handler;
import android.os.Message;

import java.util.ArrayList;
import java.util.List;

/**
 * MoveHandler
 */
public class MoveHandler extends Handler {

    private List<TickListener> listeners;

    /**
     * Constructor, starts the delayedMessage cycle
     */
    public MoveHandler() {
        listeners = new ArrayList<>();
        sendMessageDelayed(obtainMessage(), 0);
    }

    /**
     * Adds the supplied t to the listeners array
     * @param t
     */
    public void register(TickListener t) {
        listeners.add(t);
    }

    /**
     * Removes the t from the listeners array
     * @param t
     */
    public void unregister(TickListener t) {
        listeners.remove(t);
    }

    /**
     * send the message to tick to the various listeners!
     */
    public void alertListeners() {
        for (TickListener t : listeners) {
            t.tick();
        }
    }

    /**
     * alert the listeners
     */
    @Override
    public void handleMessage(Message e) {

        alertListeners();
        sendMessageDelayed(obtainMessage(), 100);

    }
}
