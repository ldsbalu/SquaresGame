package com.example.movingsquares;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author Jackson Pike
 * A relatively simple class, which draws a rectangle (Square) on given canvas, at a random position, within supplied canvas' view screen.
 * Additionally, a ID number is attached and displayed in the center of a given square, which is dynamically created sequentially through the use of a 'seed' static value.
 */
public class NumberedSquare {

    public int identifier; //ID value unique to the square
    private static int seed = 0; // Counter value to assist in unique ID'ing
    private RectF bounds; //RectF to hold the position of the square on the screen.
    private Paint tPaint, bPaint, smallText; //Two paint objects to supply color to the square. tPaint is for Text, bPaint is for the color of the square
    private float canvasWidth, canvasHeight; /* Canvas width and height are fields and assigned at construction, in order to be accessed throughout the class.
                                                           * Square size is self explanatory (The width & height of square) */
    private float squareSize;
    private static List<RectF> existingSquares;
    public PointF velocity = new PointF();
    private Random rand = new Random();
    public static Canvas c;


    /**
     * The constructor! Horray. Sets the ID, using the seed, then assigns paint fields
     * @param w - A supplied width of a canvas, in order to dynamically scale the size of the square.
     * @param h - A supplied height of a canvas,in order to dynamically scale the size of the square.
     */

    public NumberedSquare(float w, float h, boolean decrementID) {
        //decrementID is set to 'true' when a previous square was created, but resulted in an intersection. This way, ID's are preserved.
        if (decrementID) {
            seed -= 1;
        }
        if(seed == 5) { // Ensuring that ID's don't exceed 5
            seed = 0;
        }

        identifier = ++seed;
        canvasWidth = w;
        canvasHeight = h;
        squareSize = canvasWidth * 0.15f;
        existingSquares = new ArrayList<RectF>();
        bounds = genBounds();
        velocity.x = (float) (Math.random()*20)-5;
        velocity.y = (float) (Math.random()*20)-5;

        tPaint = new Paint();
        tPaint.setTextSize(100);
        tPaint.setColor(Color.rgb(46, 64, 83));

        bPaint = new Paint();
        bPaint.setStyle(Paint.Style.STROKE);
        bPaint.setStrokeWidth(canvasWidth * 0.01f);
        bPaint.setColor(Color.rgb(88, 214, 141));

        smallText = new Paint();
        smallText.setTextSize(50);
        tPaint.setColor(Color.BLACK);
    }


    /**
     * A method to contain the math of randomly finding position of square on screen, and creating a RectF storing the resulting values.
     * @return RectF containing square position on screen (Four float values, left, top, right, bottom.
     */
    public RectF genBounds() {
        Random r = new Random();
        int startingX, startingY;
        RectF potential;

        startingX = r.nextInt((int) canvasWidth - (int) squareSize);
        startingY = r.nextInt((int) canvasHeight - (int) squareSize);
        potential = new RectF(startingX, startingY, startingX+squareSize, startingY+squareSize);

        return potential;
    }

    /**
     * Method that draws the resulting rectangle and ID label on a supplied canvas.
     * @param c - The canvas in which to draw the resulting "Numbered Square" on.
     */
    public void draw(Canvas c) {

        c.drawRect(bounds, bPaint);
        c.drawText(Integer.toString(identifier), bounds.centerX()-squareSize/7, bounds.centerY()+squareSize/7, tPaint);
        this.c = c;
    }

    /**
     * Standard getter to return the RectF representation of the NumberedSquare
     * @return
     */
    public RectF getRectF() {
        return bounds;
    }

    /**
     * Move the square by the velocity, as well as bounce squares off wall, if it exceeds the canvas
     */
    public void move() {

        bounds.offset(velocity.x, velocity.y);
        if (bounds.right >= canvasWidth) {
            velocity.x *= -1;
            bounds.offsetTo(canvasWidth-squareSize-1, bounds.top);
        } else if(bounds.left <= 0) {
            velocity.x *= -1;
            bounds.offsetTo(1, bounds.top);
        } else if(bounds.top <= 0) {
            velocity.y *= -1;
            bounds.offsetTo(bounds.left, 1);
        } else if(bounds.bottom > canvasHeight) {
            velocity.y *= -1;
            bounds.offsetTo(bounds.left, canvasHeight-squareSize-1);
        }
    }

}
