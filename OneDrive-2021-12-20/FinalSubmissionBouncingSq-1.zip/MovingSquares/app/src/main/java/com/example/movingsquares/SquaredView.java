package com.example.movingsquares;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.abs;
import static java.lang.Math.min;

/**
 * @author Jackson Pike
 * A subclass view for NumberedSquare project. Overrides onDraw to create and draw 5 <code>NumberedSquare</code>'s on the canvas.
 */
public class SquaredView extends View {

    private List<NumberedSquare> squares;
    private List<NumberedSquare> collided;
    private boolean initialized = false;
    private Context c;
    float dr, dl, db, dt;

    /**
     * Inner-class that extends <code>Handler</code>
     * Our timer to move the squares and detect collisions
     */
    public class MoveHandler extends Handler {

        public MoveHandler() {
            sendMessageDelayed(obtainMessage(), 0);
        }
        @Override
        public void handleMessage(Message e) {

            for(NumberedSquare square:squares) {
                square.move();
                detectCollision();
            }

            invalidate();


            sendMessageDelayed(obtainMessage(), 10);
        }
    }
    /**
     * Constructor. Only makes call to <code>super()</code> No additional code.
     * @param c - Context
     */
    public SquaredView(Context c) {
        super(c);
        this.c = c;
        squares = new ArrayList<NumberedSquare>();
        collided = new ArrayList<NumberedSquare>();
        MoveHandler hndlr = new MoveHandler();


    }

    /**
     * Overriden onDraw Method. Draws a color on the canvas for background, and then creates and invokes the draw method of 5 numberedsquares. s
     * @param c
     */
    @Override
    public void onDraw(Canvas c) {

        if(!initialized) {
            c.drawColor(Color.rgb(254, 249, 231));
            createSquares(c, 5);

            initialized = true;
        }
        for (NumberedSquare square : squares) {
            square.draw(c);
        }
    }

    /**
     * Overriden onTouchEvent method which redraws the screen (creating a new set of NumberedSquares in the process)
     * @param e MotionEvent
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction( ) == MotionEvent.ACTION_UP) {
            squares.clear();
            initialized = false;
            invalidate();
        }
        return true;
    }

    /**
     * A method to create <code>n</code> number of squares on a given canvas.
     * @param c - A supplied canvas to give height & width to NumberedSquare constructor
     * @param n - Number of squares you want created
     */
    public void createSquares(Canvas c, int n) {
        boolean decrementNext = false;
        while(squares.size() < n) {
            NumberedSquare potential = new NumberedSquare(c.getWidth(), c.getHeight(), decrementNext);
            boolean noIntersect = true;

            for(NumberedSquare square: squares) {
                if(potential.getRectF().intersect(square.getRectF())) {
                    noIntersect = false;
                    decrementNext = true; //Since we'll be discarding this square, we need to decrement the next 'seed'. Set here.
                    break;
                }
            }
            if(noIntersect) {
                squares.add(potential);
                decrementNext = false;
            }
        }
    }

    /**
     * Checks for collided squares within the <code>squares</code> ArrayList, and if a collision (intersection) is detected,
     * gives the collided squares to {@link #bounceOff(NumberedSquare, NumberedSquare)}, to 'un' collide
     */
    public void detectCollision() {

        for(int i = 0; i < squares.size(); i++) {
            for(int j = 0; j < squares.size(); j++) {
                if(squares.get(i).identifier > squares.get(j).identifier) {
                    NumberedSquare iSquare = squares.get(i);
                    NumberedSquare jSquare = squares.get(j);
                    if (RectF.intersects(squares.get(i).getRectF(), squares.get(j).getRectF())) {
                        bounceOff(iSquare, jSquare);
                    }
                }
            }
        }
    }

    /**
     * Takes in two NumberedSquares which intersect. This method swaps the x or y velocities of the squares
     * x, if the collision is on the left or right
     * y - if the collision is on the top or bottom
     * @param iSquare - one collided <code>NumberedSquare</code>
     * @param jSquare - other collided <code>NumberedSquare</code>
     */
    private void bounceOff(NumberedSquare iSquare, NumberedSquare jSquare) {

        RectF lSquare = iSquare.getRectF();
        RectF rSquare = jSquare.getRectF();
        boolean yTrue = false;

        float dr = abs(lSquare.right - rSquare.left);
        float dl = abs(lSquare.left - rSquare.right);
        float db = abs(lSquare.bottom - rSquare.top);
        float dt = abs(lSquare.top - rSquare.bottom);

        float smallest = min(min(db, dt), min(dr, dl));

        if (smallest == dt) {
            yTrue = true;
            separate(rSquare, dt);
        } else if (smallest == db) {
            yTrue = true;
            separate(rSquare, db);
        } else if(smallest == dr) {
            separate(rSquare, dr);
        } else if(smallest == dl) {
            separate(rSquare, dl);
        }

        //Actually exchanging the velocities
        if(yTrue) {
            float tempY = iSquare.velocity.y;
            iSquare.velocity.y = jSquare.velocity.y;
            jSquare.velocity.y = tempY;
        } else {
            float tempX = iSquare.velocity.x;
            iSquare.velocity.x = jSquare.velocity.x;
            jSquare.velocity.x = tempX;
        }
    }

    private void separate(RectF rSquare, float seed) {
        int dx = 0;
        int dy = 0;
        if(seed == dt) {
            dy = -5;
        } else if(seed == db) {
            dy = 5;
        } else if(seed == dr) {
            dx = 5;
        } else if(seed == dl) {
            dx = -5;
        }
        rSquare.offset(dx, dy);

    }
}

