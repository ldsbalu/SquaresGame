package com.example.movingsquares;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Jackson Pike
 * A subclass view for NumberedSquare project. Overrides onDraw to create and draw 5 <code>NumberedSquare</code>'s on the canvas.
 */
public class SquaredView extends View {

    private List<NumberedSquare> squares;
    private boolean initialized = false;
    /**
     * Constructor. Only makes call to <code>super()</code> No additional code.
     * @param c - Context
     */

    public class MoveHandler extends Handler {

        public MoveHandler() {
            sendMessageDelayed(obtainMessage(), 0);
        }
        @Override
        public void handleMessage(Message e) {
            for(NumberedSquare s:squares) {
                s.move();

            }
            invalidate();


            sendMessageDelayed(obtainMessage(), 100);
        }
    }

    public SquaredView(Context c) {
        super(c);
        squares = new ArrayList<NumberedSquare>();
        MoveHandler hndlr = new MoveHandler();

    }

    /**
     * Overriden onDraw Method. Draws a color on the canvas for background, and then creates and invokes the draw method of 5 numberedsquares. s
     * @param c
     */
    @Override
    public void onDraw(Canvas c) {

        if(!initialized) {
            c.drawColor(Color.rgb(254, 249, 231));
            createSquares(c, 5);
            initialized = true;
        }
        for (NumberedSquare square : squares) {
            square.draw(c);
        }
    }

    /**
     * Overriden onTouchEvent method which redraws the screen (creating a new set of NumberedSquares in the process)
     * @param e MotionEvent
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction( ) == MotionEvent.ACTION_UP) {
            squares.clear();
            initialized = false;
            invalidate();
        }
        return true;
    }

    /**
     * A method to create <code>n</code> number of squares on a given canvas.
     * @param c - A supplied canvas to give height & width to NumberedSquare constructor
     * @param n - Number of squares you want created
     */
    public void createSquares(Canvas c, int n) {
        boolean decrementNext = false;
        while(squares.size() < n) {
            NumberedSquare potential = new NumberedSquare(c.getWidth(), c.getHeight(), decrementNext);
            boolean noIntersect = true;

            for(NumberedSquare square: squares) {
                if(potential.getRectF().intersect(square.getRectF())) {
                    noIntersect = false;
                    decrementNext = true; //Since we'll be discarding this square, we need to decrement the next 'seed'. Set here.
                    break;
                }
            }
            if(noIntersect) {
                squares.add(potential);
                decrementNext = false;
            }
        }
    }
}

